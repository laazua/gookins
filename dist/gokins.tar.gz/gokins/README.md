### gokins


* **PipeLine**
```
curl -X POST http://localhost:8885/pipeline/execute \
  -H "Content-Type: application/yaml" \
  -d '
name: Complex Pipeline Example

triggers:
  - type: push
    branch: main
  - type: pull_request

stages:
  - name: Build
    steps:
      - name: Setup
        command: make setup
        env:
          ENV: production
      - name: Compile
        command: make build
        condition: success()

  - name: Test
    steps:
      - name: Unit Tests
        parallel:
          - name: Backend Tests
            command: make test-backend
          - name: Frontend Tests
            command: make test-frontend
      - name: Integration Tests
        command: make test-integration
        condition: success()

  - name: Deploy
    steps:
      - name: Deploy to Staging
        plugin: deploy
        env:
          ENVIRONMENT: staging
      - name: Smoke Tests
        command: make smoke-tests
      - name: Deploy to Production
        plugin: deploy
        env:
          ENVIRONMENT: production
        condition: success() && branch == 'main'
’
```

* **测试**

```
curl -X POST http://localhost:8885/pipeline/execute \
  -H "Content-Type: application/yaml" \
  -d '
name: 测试流水线

triggers:
  - type: push
    branch: main

stages:
  - name: Build
    steps:
      - name: Setup
        command: echo "Setting up environment"
        env:
          ENV: test
      - name: Compile
        command: echo "Compiling code" && sleep 20
        condition: success()

  - name: Test
    steps:
      - name: Unit Tests
        parallel:
          - name: Backend Tests
            command: echo "Running backend tests"
          - name: Frontend Tests
            command: echo "Running frontend tests"
      - name: Integration Tests
        command: echo "Running integration tests"
        condition: success()

  - name: Deploy
    steps:
      - name: Deploy to Staging
        plugin: deploy
        env:
          ENVIRONMENT: staging
      - name: Smoke Tests
        command: echo "Running smoke tests"
      - name: Deploy to Production
        plugin: deploy
        env:
          ENVIRONMENT: production
        condition: success() && branch == '"'"'main'"'"'
'
```


```
curl -X POST http://localhost:8885/pipeline/execute \
  -H "Content-Type: application/yaml" \
  -d '
name: 示例流水线

triggers:
  - type: push
    branch: main

stages:
  - name: 构建阶段
    steps:
      - name: 设置环境变量
        command: echo "获取环境变量: $ENVIRONMENT"
        env:
          ENVIRONMENT: test
      - name: 编译代码
        command: echo "正在编译代码" && sleep 20
        condition: success()

  - name: 测试阶段
    steps:
      - name: 单元测试
        parallel:
          - name: 后端测试
            command: echo "正在运行后端测试" && sleep 10
          - name: 前端测试
            command: echo "正在进行前端测试"
      - name: 整合测试
        command: echo "正在运行整合测试"
        condition: success()

  - name: 部署阶段
    steps:
      - name: 部署到预发布环境
        plugin: shell
        env:
          ENVIRONMENT: staging
      - name: 冒烟测试
        command: echo "正在进行冒烟测试"
      - name: 部署到生产环境
        plugin: shell
        env:
          ENVIRONMENT: production
        condition: success() && branch == "main"
'
```


```
curl -X POST http://localhost:8885/pipeline/execute \
  -H "Content-Type: application/yaml" \
  -d '
name: 示例流水线

triggers:
  - type: push
    branch: main

stages:
  - name: 构建阶段
    steps:
    - name: 设置环境变量
      env:
        USERNAME: 张三
        PASSWORD: 111111
      command: echo "==== $USERNAME $PASSWORD"
      condition: true

    - name: 获取目标代码
      command: echo "==== 正在拉取代码"
      condition: false
  
  - name: 测试阶段
    steps:
    - name: 模糊测试
      command: echo "==== aaaaa"
      condition: true
    - name: 集成测试
      command: echo "==== bbbbb"
      condition: true
'
```

* **demo**
```
name: 示例流水线

triggers:
  - type: push
    branch: main

stages:
  - name: 构建阶段
    steps:
    - name: 设置环境变量
      env:
        USERNAME: 张三
        PASSWORD: 111111
      command: echo "==== $USERNAME $PASSWORD"
      condition: true

    - name: 获取目标代码
      command: echo "==== 正在拉取代码"
      condition: false
  
  - name: 测试阶段
    steps:
    - name: 模糊测试
      command: echo "==== aaaaa"
      condition: true
    - name: 集成测试
      command: echo "==== bbbbb"
      condition: true
```