package main

import (
	"fmt"
	"gokins/internal/api"
	"gokins/internal/config"
	"gokins/internal/core"
	"log"
	"log/slog"
	"net/http"

	"github.com/gin-gonic/gin"
)

func main() {
	cfg, err := config.Load()
	if err != nil {
		slog.Error(err.Error())
		return
	}

	engine := core.NewEngine(cfg)
	router := gin.New()
	api.SetupRoutes(router, engine)

	slog.Info(fmt.Sprintf("Starting server on %s", cfg.ServAddress))
	if err := http.ListenAndServe(cfg.ServAddress, router); err != nil {
		log.Fatalf("Failed to start server: %v", err)
	}
}
