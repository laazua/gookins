package core

import (
	"context"
	"fmt"
	"log/slog"
	"os/exec"
	"strings"
	"sync"
	"time"

	"gokins/internal/config"
	"gokins/internal/parser"
	"gokins/internal/plugin"
	"gokins/internal/types"
)

var conditionHandlers = map[string]func() bool{
	"success()": func() bool { return true },
	"failure()": func() bool { return false },
}

type Engine struct {
	config            *config.Config
	parser            *parser.YAMLParser
	mutex             sync.Mutex
	jobs              chan *types.PipeLine
	conditionHandlers map[string]func() bool
}

func NewEngine(cfg *config.Config) *Engine {
	e := &Engine{
		config:            cfg,
		parser:            parser.NewYAMLParser(),
		jobs:              make(chan *types.PipeLine, cfg.ConcurrentJobs),
		conditionHandlers: conditionHandlers,
	}
	for i := 0; i < cfg.ConcurrentJobs; i++ {
		go e.worker()
	}
	return e
}

func (e *Engine) worker() {
	// 设置超时时间
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	for pipeline := range e.jobs {
		e.executePipeline(ctx, pipeline)
	}
}

func (e *Engine) LoadPipelineFromYAML(yamlContent string) (*types.PipeLine, error) {
	pipeline, err := e.parser.Parse(yamlContent)
	if err != nil {
		return nil, fmt.Errorf("解析流水线YAML失败: %w", err)
	}
	return pipeline, nil
}

func (e *Engine) ExecutePipeline(ctx context.Context, pipeline *types.PipeLine) error {
	select {
	case e.jobs <- pipeline:
		return nil
	default:
		return fmt.Errorf("流水线任务队列已满")
	}
}

func (e *Engine) executePipeline(ctx context.Context, pipeline *types.PipeLine) error {
	fmt.Printf("##### 执行任务名: %s #####\n", pipeline.Name)
	for _, stage := range pipeline.Stages {
		if err := e.executeStage(ctx, stage); err != nil {
			return err
		}
		fmt.Println("+++++++++++++++++++++++++++++++++++++++++++++++")
	}
	return nil
}

func (e *Engine) executeStage(ctx context.Context, stage types.Stage) error {
	var wg sync.WaitGroup
	errChan := make(chan error, len(stage.Steps))

	fmt.Printf("***** 执行阶段: %s *****\n", stage.Name)
	for i := range stage.Steps {
		wg.Add(1)
		go func(s *types.Step) {
			defer wg.Done()
			if err := e.executeStep(ctx, s); err != nil {
				errChan <- err
			}
		}(&stage.Steps[i])
	}

	go func() {
		wg.Wait()
		close(errChan)
	}()

	for err := range errChan {
		if err != nil {
			return err
		}
	}

	return nil
}

func (e *Engine) executeStep(ctx context.Context, step *types.Step) error {
	e.updateStepStatus(step, types.StatusRunning)

	if !e.evaluateCondition(step.Condition) {
		fmt.Printf("步骤: %s, 条件不满足，跳过执行\n", step.Name)
		e.updateStepStatus(step, types.StatusSkipped)
		return nil
	}

	var err error
	if len(step.Parallel) > 0 {
		err = e.executeParallelSteps(ctx, step.Parallel)
	} else if step.Plugin != "" {
		err = e.executePlugin(step)
	} else {
		err = e.executeCommand(ctx, step)
	}

	if err != nil {
		e.updateStepStatus(step, types.StatusFailed)
		return err
	}
	slog.Info(step.Name)
	e.updateStepStatus(step, types.StatusSucceeded)
	return nil
}

func (e *Engine) executeParallelSteps(ctx context.Context, steps []types.Step) error {
	var wg sync.WaitGroup
	errChan := make(chan error, len(steps))

	for i := range steps {
		wg.Add(1)
		go func(s *types.Step) {
			defer wg.Done()
			if err := e.executeStep(ctx, s); err != nil {
				errChan <- err
			}
		}(&steps[i])
	}

	go func() {
		wg.Wait()
		close(errChan)
	}()

	for err := range errChan {
		if err != nil {
			return err
		}
	}

	return nil
}

func (e *Engine) executePlugin(step *types.Step) error {
	p, ok := plugin.GetPlugin(step.Plugin)
	if !ok {
		return fmt.Errorf("插件 %s 未找到", step.Plugin)
	}

	pluginCtx := plugin.Context{
		WorkspacePath: e.config.WorkspacePath,
		EnvVars:       step.Env,
	}

	return p.Execute(pluginCtx)
}

// 执行: pipeLine中的命令
func (e *Engine) executeCommand(ctx context.Context, step *types.Step) error {
	var cmd *exec.Cmd

	switch {
	case strings.HasSuffix(step.Command, ".py"):
		cmd = exec.CommandContext(ctx, "python", step.Command)
	case strings.HasSuffix(step.Command, ".sh"):
		cmd = exec.CommandContext(ctx, "bash", step.Command)
	default:
		cmd = exec.CommandContext(ctx, "sh", "-c", step.Command)
	}

	cmd.Env = append(cmd.Env, e.envVarsToSlice(step.Env)...)
	cmd.Dir = e.config.WorkspacePath

	output, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("命令执行失败: %w\n输出: %s", err, string(output))
	}

	fmt.Printf("命令输出 ===>:\n%s\n", string(output))
	return nil
}

// 设置: 命令上下文可用的环境变量
func (e *Engine) envVarsToSlice(envVars map[string]string) []string {
	var result []string
	for k, v := range envVars {
		result = append(result, fmt.Sprintf("%s=%s", k, v))
	}
	return result
}

// 设置: 条件满足则执行
func (e *Engine) evaluateCondition(condition interface{}) bool {
	switch v := condition.(type) {
	case bool:
		return v
	case string:
		return strings.ToLower(v) == "true"
	default:
		fmt.Printf("不支持的条件类型: %T\n", condition)
		return false
	}
}

func (e *Engine) updateStepStatus(step *types.Step, status types.StepStatus) {
	e.mutex.Lock()
	defer e.mutex.Unlock()
	step.Status = status
	// 这里可以添加将状态保存到数据库的逻辑
	fmt.Printf("步骤 %s 状态更新 %s\n", step.Name, status)
}
