package parser

import (
	"fmt"

	"gokins/internal/types"

	"gopkg.in/yaml.v3"
)

type YAMLParser struct{}

func NewYAMLParser() *YAMLParser {

	return &YAMLParser{}
}

func (p *YAMLParser) Parse(content string) (*types.PipeLine, error) {
	var rawPipeline struct {
		Name     string          `yaml:"name"`
		Stages   []yaml.Node     `yaml:"stages"`
		Triggers []types.Trigger `yaml:"triggers"`
	}

	err := yaml.Unmarshal([]byte(content), &rawPipeline)
	if err != nil {
		return nil, fmt.Errorf("解析YAML失败: %w", err)
	}

	pipeline := &types.PipeLine{
		Name:     rawPipeline.Name,
		Triggers: rawPipeline.Triggers,
	}

	for _, stageNode := range rawPipeline.Stages {
		stage, err := p.parseStage(stageNode)
		if err != nil {
			return nil, err
		}
		pipeline.Stages = append(pipeline.Stages, stage)
	}

	return pipeline, nil
}

func (p *YAMLParser) parseStage(node yaml.Node) (types.Stage, error) {
	var stage types.Stage
	var rawStage struct {
		Name  string      `yaml:"name"`
		Steps []yaml.Node `yaml:"steps"`
	}

	err := node.Decode(&rawStage)
	if err != nil {
		return stage, fmt.Errorf("failed to parse stage: %w", err)
	}

	stage.Name = rawStage.Name

	for _, stepNode := range rawStage.Steps {
		step, err := p.parseStep(stepNode)
		if err != nil {
			return stage, err
		}
		stage.Steps = append(stage.Steps, step)
	}

	return stage, nil
}

func (p *YAMLParser) parseStep(node yaml.Node) (types.Step, error) {
	var step types.Step
	var rawStep struct {
		Name      string            `yaml:"name"`
		Command   string            `yaml:"command"`
		Plugin    string            `yaml:"plugin"`
		Env       map[string]string `yaml:"env"`
		Condition string            `yaml:"condition"`
		Parallel  []yaml.Node       `yaml:"parallel"`
	}

	err := node.Decode(&rawStep)
	if err != nil {
		return step, fmt.Errorf("failed to parse step: %w", err)
	}

	step.Name = rawStep.Name
	step.Command = rawStep.Command
	step.Plugin = rawStep.Plugin
	step.Env = rawStep.Env
	step.Condition = rawStep.Condition

	if len(rawStep.Parallel) > 0 {
		for _, parallelStepNode := range rawStep.Parallel {
			parallelStep, err := p.parseStep(parallelStepNode)
			if err != nil {
				return step, err
			}
			step.Parallel = append(step.Parallel, parallelStep)
		}
	}

	return step, nil
}
