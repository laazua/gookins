package types

type StepStatus string

const (
	StatusPending   StepStatus = "pending"
	StatusRunning   StepStatus = "running"
	StatusSucceeded StepStatus = "succeeded"
	StatusFailed    StepStatus = "failed"
	StatusSkipped   StepStatus = "skipped"
)

type PipeLine struct {
	ID       string    `yaml:"id"`
	Name     string    `yaml:"name"`
	Stages   []Stage   `yaml:"stages"`
	Triggers []Trigger `yaml:"triggers"`
}

type Stage struct {
	Name  string `yaml:"name"`
	Steps []Step `yaml:"steps"`
}

type Step struct {
	Name      string            `yaml:"name"`
	Command   string            `yaml:"command"`
	Plugin    string            `yaml:"plugin"`
	Env       map[string]string `yaml:"env"`       // 执行命令上下文中的环境变量
	Condition string            `yaml:"condition"` // 根据特定条件觉得是否执行某特stage
	Parallel  []Step            `yaml:"parallel"`
	Status    StepStatus        `yaml:"-"`
}

type Trigger struct {
	Type   string `yaml:"type"`
	Branch string `yaml:"branch"`
}
