package plugin

import (
	"fmt"
	"os/exec"
)

type GitPlugin struct{}

func init() {
	RegisterPlugin("git", &GitPlugin{})
}

func (p *GitPlugin) Execute(ctx Context) error {
	cmd := exec.Command("git", "status")
	cmd.Dir = ctx.WorkspacePath
	output, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("git status failed: %w", err)
	}
	fmt.Printf("Git status output:\n%s\n", string(output))
	return nil
}

func (p *GitPlugin) GetName() string {
	return "git"
}
