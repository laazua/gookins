package plugin

import (
	"fmt"
	"os/exec"
)

type DockerPlugin struct{}

func init() {
	RegisterPlugin("docker", &DockerPlugin{})
}

func (p *DockerPlugin) Execute(ctx Context) error {
	cmd := exec.Command("docker", "build", "-t", "myapp", ".")
	cmd.Dir = ctx.WorkspacePath
	cmd.Env = append(cmd.Env, formatEnvVars(ctx.EnvVars)...)
	output, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("docker build failed: %w", err)
	}
	fmt.Printf("Docker build output:\n%s\n", string(output))
	return nil
}

func (p *DockerPlugin) GetName() string {
	return "docker"
}

func formatEnvVars(envVars map[string]string) []string {
	var env []string
	for k, v := range envVars {
		env = append(env, fmt.Sprintf("%s=%s", k, v))
	}
	return env
}
