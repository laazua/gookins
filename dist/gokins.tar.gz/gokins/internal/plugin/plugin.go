package plugin

type Context struct {
	WorkspacePath string
	EnvVars       map[string]string
}

type Plugin interface {
	Execute(context Context) error
	GetName() string
}

var registry = make(map[string]Plugin)

func Register(p Plugin) {
	registry[p.GetName()] = p
}

// func GetPlugin(name string) (Plugin, error) {
// 	p, ok := registry[name]
// 	if !ok {
// 		return nil, fmt.Errorf("plugin %s not found", name)
// 	}
// 	return p, nil
// }
