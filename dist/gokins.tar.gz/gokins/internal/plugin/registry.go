package plugin

import "sync"

var (
	pluginsMu sync.RWMutex
	plugins   = make(map[string]Plugin)
)

func RegisterPlugin(name string, p Plugin) {
	pluginsMu.Lock()
	defer pluginsMu.Unlock()
	if _, dup := plugins[name]; dup {
		panic("plugin: RegisterPlugin called twice for plugin " + name)
	}
	plugins[name] = p
}

func GetPlugin(name string) (Plugin, bool) {
	pluginsMu.RLock()
	defer pluginsMu.RUnlock()
	p, ok := plugins[name]
	return p, ok
}

func Plugins() []string {
	pluginsMu.RLock()
	defer pluginsMu.RUnlock()
	var list []string
	for name := range plugins {
		list = append(list, name)
	}
	return list
}
