package api

import (
	"io"
	"net/http"

	"gokins/internal/core"

	"github.com/gin-gonic/gin"
)

type Handler struct {
	engine *core.Engine
}

func NewHandler(engine *core.Engine) *Handler {
	return &Handler{engine: engine}
}

func (h *Handler) ExecutePipeline(c *gin.Context) {
	body, err := io.ReadAll(c.Request.Body)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Failed to read request body"})
		return
	}

	pipeline, err := h.engine.LoadPipelineFromYAML(string(body))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Failed to parse YAML: " + err.Error()})
		return
	}

	err = h.engine.ExecutePipeline(c.Request.Context(), pipeline)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to execute pipeline: " + err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Pipeline queued for execution"})
}

func SetupRoutes(r *gin.Engine, engine *core.Engine) {
	handler := NewHandler(engine)
	r.POST("/pipeline/execute", handler.ExecutePipeline)
}
